#Segunda solución
n = 0
aux  = 0

palabra = input("Escriba una palabra: ")

for ind in reversed(range(0, len(palabra))):
    if palabra[ind].lower() == palabra[aux].lower():
        n += 1
    aux += 1

if len(palabra) == n:
    print("Es un palindromo")
else:
    print("No es un palindromo")

