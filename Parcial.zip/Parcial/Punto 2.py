def sime(x, n):
    if n<1:
        return x[0]
    else:
        return x[n]+ sime(x,n-1)

x = input("Digite palabra: ")
n = len(x)-1
y = sime(x,n)
if x==y:
    print("Es un palíndromo")
else:
    print("No es un palíndromo")
