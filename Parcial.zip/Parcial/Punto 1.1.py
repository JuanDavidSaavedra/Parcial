import random
n = int(input("Digite n"))
v1 = []

for i in range (1,102):
    v1.append(0)

for i in range (n):
    x = random.randint(1,100)
    v1[x] = v1[x] + 1

print(v1)
print(max(v1))
print(max(v1)-1)
