import random as random
from time import time 

inicio = time()
lista_numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
            16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
            31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45,
            46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60,
            61, 62, 63, 64, 65, 66, 67, 68, 68, 69, 70, 71, 72, 73, 74,
            75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89,
            90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100]

lista_contador = dict()
seguidor = 0

#-----------------------------------------------------------------------

arreglo = []
n = 2000

def burbuja_optimus(arreglo):
    n = len(arreglo)
  
    for i in range(n-1):
        intercambio = False
 
        for j in range(n-1-i):
            if arreglo[j] > arreglo[j+1] :
                arreglo[j], arreglo[j+1] = arreglo[j+1], arreglo[j]
                intercambio = True
 
        if intercambio == False:
            break

for i in range(n):
    arreglo.append(random.randint(1,100))

#-----------------------------------------------------------------------

#Conteo de números y cantidad de veces generados

for i in range(len(lista_numeros)):
    valor=0
    for j in range(len(arreglo)):
        if(arreglo[j]==lista_numeros[i]):
            valor+=1
            lista_contador[lista_numeros[i]]=valor

for i in range(len(lista_numeros)-seguidor):
        if lista_numeros[i-seguidor] in lista_contador:
            lista_numeros.remove(lista_numeros[i-seguidor])
            seguidor+=1
            

burbuja_optimus(arreglo)

print("\nArray generado: ")
print(arreglo, "\n")

print("\nConteo de cantidad de números generados por cada número de 1 a 100:")
print(lista_contador, "\n")

print("\nValores cuya cantidad en el arreglo generado es 0 (no se generaron ni una sola vez): ")
print(lista_numeros, "\n")

print("\nLos 4 primeros números con mayores veces generadas en la muestra fueron: ")
print(str(arreglo[0]) + ", " + str(arreglo[1]) + ", " + str(arreglo[2]) + ", " + str(arreglo[3]) + "\n")

tiempo = time() - inicio
print("\nTiempo de ejecucción: ", str(tiempo) + "\n")