#Tercera solución

def palindromo(palabra):
    letras_al_reves = []

    for letra in palabra:
        letras_al_reves.insert(0, letra)
    palabra_al_reves = ''.join(letras_al_reves)

    if palabra_al_reves == palabra:
        return True
    return False

def palindromo2(palabra):
    palabra_al_reves =palabra[::-1]

    if palabra_al_reves == palabra:
        return True
    return False

if __name__ == '__main__':
    palabra = input('Escriba una palabra: ')
    resultado = palindromo2(palabra)

    if resultado is True:
        print('Es un palindromo')
    else:
        print('No un palindromo')